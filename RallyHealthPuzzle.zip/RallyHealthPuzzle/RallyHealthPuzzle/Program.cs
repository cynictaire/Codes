﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 * Aiden Thinn
 * Software Engineer Intern Puzzle - Rally Health
 * */
namespace RallyHealthPuzzle
{
    class Program
    {
        static void Main(string[] args)
        {
            //Attributes
            int runners = 0; //Number of runners group will need to see running
            int shareRunners= 0; //Number of runners who share that "run number"

            //Loop through with the amount of Rallyers that are attending the HealthFest
            for(int i = 0; i < 7; i++)
            {
                //Increment the runners
                runners++;

                //Runners who share the run number will be the result of runners in addition to the loop variable
                shareRunners = runners + i;

                //Print out each line
                Console.WriteLine(shareRunners + " person/people will need to see " + runners + " runner(s) before running");
            }
        }
    }
}
